WebTiles - Manual
---------------------------------

A tool to tile multiple Chromium-based browser windows on the screen.

# Features
- Launch URLs in new windows
- Tile windows across the screen
- Ask to close opened windows when finished

# How to use
1. Run WebTiles.exe.
2. On first run, WebTiles.json is created; edit it (see the example).
3. Run again to launch and tile the browser windows.
4. After launch, a message box asks whether to close all opened windows.

# Config file
WebTiles.json is created in the same folder at runtime.

Example:
{
  "version": "1.0",
  "rows": 2,
  "cols": 2,
  "chromiumPath": "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe",
  "urls": [
    "about:blank",
    "about:blank",
    "about:blank",
    "about:blank"
  ]
}

 - "rows" : number of rows
 - "cols" : number of columns
 - "chromiumPath" : path to Chromium-based browser exe (Edge/Chrome/Brave)
 - "urls" : list of URLs to open (fit within rows x cols)

# License
See LICENSE.txt.

------------------------------------------------------------------

WebTiles - 取扱説明書
---------------------------------

Chromium 系ブラウザウィンドウをタイル状に複数整列するためのアプリです。

# 機能
- 指定した URL を新しいウィンドウで起動
- 画面全体にタイル配置
- 実行後にウィンドウを閉じる確認を表示

# 使い方
1. WebTiles.exe を実行します。
2. 初回実行で WebTiles.json が作成されるので内容を編集します。（例を参照）
3. 再度実行すると設定に従ってブラウザが起動・整列します。
4. 起動後、ブラウザをまとめて閉じるか確認するメッセージがボックスが表示されます。

# 設定ファイル
WebTiles.json は実行時に同じフォルダに作成されます。

例:
{
  "version": "1.0",
  "rows": 2,
  "cols": 2,
  "chromiumPath": "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe",
  "urls": [
    "about:blank",
    "about:blank",
    "about:blank",
    "about:blank"
  ]
}

 - "rows" : タイルの行数
 - "cols" : タイルの列数
 - "chromiumPath" : Chromium のパス。edge や chrome などの exe へのパスを指定します。
 - "urls" : 開く URL のリスト。行列に収まる数を記入します。

# ライセンス
LICENSE.txt を参照してください。
